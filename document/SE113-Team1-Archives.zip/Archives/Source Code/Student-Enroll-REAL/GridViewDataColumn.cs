﻿namespace Student_Enroll_REAL
{
    internal class GridViewDataColumn
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows;

namespace Student_Enroll_REAL.SQLInteraction
{
    

    class SQLConnector
    {

    public static string ConnectionString = "Data Source=SQL5105.site4now.net;Initial Catalog=db_a7d89c_phungthanhtu2;User Id=db_a7d89c_phungthanhtu2_admin;Password=Phungthanhtu!1";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Student_Enroll_REAL.Authentication
{
    static class User
    {
        public static string Login_status = "unknown";
    }
}
